/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio6.models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author
 */
public class Authentication {

    private Connection conexion;
    private static User user = new User();

    private void abrirConexion() throws SQLException {
        String dbURI = "jdbc:derby://localhost:1527/Comentarios";

        String username = "fcfm";
        String password = "lsti01";
        conexion = DriverManager.getConnection(dbURI, username, password);

    }

    private void cerrarConexion() throws SQLException {
        conexion.close();
    }

    public void insertar(User user) {
        try {
            abrirConexion();
            String sql = "insert into SESIONES values('" + user.getUsername() + "'," + "'" + user.getPassword() + "')";
            Statement stmt = conexion.createStatement();
            stmt.executeUpdate(sql);
            cerrarConexion();

        } catch (SQLException sqle) {
            System.out.println("se bugeo:v");
        }

    }

    public void buscar(String username, String password) {
        try {
            abrirConexion();
            String sql = "select * from SESIONES where USUARIO = '" + username + "' and CONTRASENIA like '%" + password + "%'";
            Statement stmt = conexion.createStatement();
            ResultSet mensajes = stmt.executeQuery(sql);
            while (mensajes.next()) {
                String usuario = mensajes.getString("usuario");
                String contrasenia = mensajes.getString("contrasenia");
                user.setUsername(usuario);
                user.setPassword(contrasenia);
            }
            cerrarConexion();
        } catch (SQLException sq) {
            System.out.println("Se bugeo:v x2");
        }
    }
    public static boolean authenticate(String username, String password) {
        String userDataBase = user.getUsername();
        String passwordDataBase = user.getPassword();

        if (username.equals(userDataBase) && password.equals(passwordDataBase)) {
            return true;
        } else {
            return false;
        }
    }

}
